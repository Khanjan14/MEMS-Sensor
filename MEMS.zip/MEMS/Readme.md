#Accelerometer

This contains interface of LIS3DH accelerometer implemented in Keil uVision V5.The colour LEDs will glow
according to the direction in which board is tilted.

***Requred Software Components (uVISION 5)

Device: Startup, Common, Cortex, DMA, GPIO, I2C, PWR, RCC, SPI 

***Flash-> Configure Flash Tools->C/C++ -> Include Paths : Browse to Inc directory in MEMS.

The reference code is the BSP(Board Support) which is provided in Keil's STM32F4xx Software Pack.
